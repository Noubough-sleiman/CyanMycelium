/* This fakes the situation where other.proto was not found at generation time,
   so size_union declarations are generated. */

#define SecondOneof_size 88
#define AnotherList_size 88

#include "oneof.pb.h"
