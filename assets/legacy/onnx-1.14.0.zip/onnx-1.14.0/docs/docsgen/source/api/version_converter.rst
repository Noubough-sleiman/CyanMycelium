
onnx.version_converter
======================


convert_version
+++++++++++++++

.. autofunction:: onnx.version_converter.convert_version
