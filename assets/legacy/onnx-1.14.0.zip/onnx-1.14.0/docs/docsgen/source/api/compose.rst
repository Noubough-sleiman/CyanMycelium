
onnx.compose
============


.. currentmodule:: onnx.compose

.. autosummary::

    merge_graphs
    merge_models

merge_graphs
++++++++++++

.. autofunction:: onnx.compose.merge_graphs

merge_models
++++++++++++

.. autofunction:: onnx.compose.merge_models

prefix
++++++

.. autofunction:: onnx.compose.add_prefix_graph

.. autofunction:: onnx.compose.add_prefix

dimension
+++++++++

.. autofunction:: onnx.compose.expand_out_dim

.. autofunction:: onnx.compose.expand_out_dim_graph
