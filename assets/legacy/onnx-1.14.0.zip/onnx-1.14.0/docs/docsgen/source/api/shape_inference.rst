
onnx.shape_inference
====================


infer_shapes
++++++++++++

.. autofunction:: onnx.shape_inference.infer_shapes

infer_shapes_path
+++++++++++++++++

.. autofunction:: onnx.shape_inference.infer_shapes_path

infer_function_output_types
+++++++++++++++++++++++++++

.. autofunction:: onnx.shape_inference.infer_function_output_types