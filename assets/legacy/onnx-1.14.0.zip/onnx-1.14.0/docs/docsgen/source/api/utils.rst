
onnx.utils
==========


Extractor
+++++++++

.. autoclass:: onnx.utils.Extractor
    :members:

extract_model
+++++++++++++

.. autofunction:: onnx.utils.extract_model
