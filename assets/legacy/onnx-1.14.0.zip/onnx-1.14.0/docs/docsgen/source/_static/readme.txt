diff2html: https://github.com/rtfpessoa/diff2html, license MIT
