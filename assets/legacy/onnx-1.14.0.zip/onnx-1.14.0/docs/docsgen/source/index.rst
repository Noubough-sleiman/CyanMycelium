.. Copyright (c) ONNX Project Contributors
..
.. SPDX-License-Identifier: Apache-2.0

.. _l-main-doc-page:

ONNX documentation
==================

.. toctree::
    :maxdepth: 2

    intro/index
    api/index
    operators/index
    technical/index
