/*
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

// clang-format off
#include "onnx/onnx_pb.h"
#include "onnx/onnx-data.pb.h"
// clang-format on
